var operators = ["+", "-", "/", "*"];
var amswertext = null;
var last_operation_history = null;
var operator = null;
var dot = null;
var firstNum = true;
var numbers = [];
var operator_value;
var last_button;
var calc_operator;
var total;
var key_combination = []
var lastchar = null;
var last_operator = null;
var historycharfirst = null

function button_number(btnclickValue) {
    operator = document.getElementsByClassName("operator");
    amswertext = document.getElementById("box");
    last_operation_history = document.getElementById("last_operation_history");
    dot = document.getElementById("dot").value;
    last_button = btnclickValue;

    if (!operators.includes(btnclickValue) && btnclickValue != "=") {
        historycharfirst = btnclickValue;
        if (firstNum) {
            if (btnclickValue == ".") {
                amswertext.innerText = "0" + dot;
            }
            else {
                amswertext.innerText = btnclickValue;
            }
            firstNum = false;
        }
        else {

            if (amswertext.innerText.length == 1 && amswertext.innerText == 0) {
                if (btnclickValue == ".") {
                    amswertext.innerText += btnclickValue;
                }
                return;
            }

            if (amswertext.innerText.includes(".") && btnclickValue == ".") {
                return;
            }

            if (amswertext.innerText.length == 20) {
                return;
            }
            else {
                amswertext.innerText += btnclickValue;
            }
        }
    }

    //oprator && ==
    else {

        if (lastchar != "=" && lastchar != null && lastchar == btnclickValue) {
            return
        } else if (operators.includes(lastchar) && btnclickValue != "=") {
            lastchar = btnclickValue;
            calc_operator = lastchar;
            last_operator = lastchar;
            console.log("la" + lastchar + "====" + calc_operator + "===" + btnclickValue)
            let str = last_operation_history.innerText;
            str = str.substring(0, str.length - 1);
            last_operation_history.innerText = str + " " + lastchar
            return
        }


        if (operators.includes(btnclickValue)) {
            if (typeof last_operator != "undefined" && last_operator != null) {
                calc_operator = last_operator
                //console.log("lbbbbbbb" + lastchar + "====" + calc_operator + "===" + btnclickValue)
            }
            else if (operators.includes(lastchar)) {
                lastchar = btnclickValue;
                calc_operator = lastchar;
                // console.log("laaaaaaaaaaa" + lastchar + "====" + calc_operator + "===" + btnclickValue)
            }
            else {
                calc_operator = btnclickValue
            }
            if (btnclickValue == "*") {
                last_operator = "×"
            }
            else if (btnclickValue == "/") {
                last_operator = "÷"
            }
            else {
                last_operator = btnclickValue
            }

            operator_value = btnclickValue
            firstNum = true
            // console.log("cccccccccccc" + lastchar + "====" + calc_operator + "===" + btnclickValue)
        }

        //history
        if (numbers.length == 0) {

            if (typeof last_operator != "undefined" && last_operator != null) {
                numbers.push(amswertext.innerText)
                last_operation_history.innerText = amswertext.innerText + " " + last_operator
            } else if (btnclickValue == "=") {
                last_operation_history.innerText = amswertext.innerText + "="
                return;
            }
        }

        else {
            if (numbers.length == 1) {
                numbers[1] = amswertext.innerText
            }

            var temp_num = amswertext.innerText
            if (btnclickValue == "=" && calc_operator != null || operators.includes(btnclickValue)) {

                if (calc_operator == "×") {
                    calc_operator = "*"
                }

                // console.log("====number[0]====>" + numbers[0] + "=====number[1]========>" + numbers[1] + "=====cal=====>" + calc_operator +
                //     "=btnclick=>" + btnclickValue + "===last>" + lastchar);

                var total;

                if (operators.includes(btnclickValue) && lastchar == "=") {
                    total = numbers[0]
                    amswertext.innerText = total;
                }
                else if (btnclickValue == "=" && lastchar == "=") {

                    total = calculate(historycharfirst, amswertext.innerText, calc_operator)
                    amswertext.innerText = total;
                }
                else {
                    total = calculate(numbers[0], numbers[1], calc_operator)
                    amswertext.innerText = total;
                }

                if (!last_operation_history.innerText.includes("=")) {
                    last_operation_history.innerText += " " + numbers[1] + " ="
                }


                var history_arr = [];
                if (operators.includes(btnclickValue) && lastchar == "=") {
                    history_arr[0] = amswertext.innerText + last_operator;
                }
                else if (btnclickValue == "=" && lastchar == "=") {

                    history_arr[0] = numbers[0] + last_operator + historycharfirst + "=";
                }
                else if (btnclickValue == "=") {
                    history_arr[0] = numbers[0] + calc_operator + numbers[1] + "=";
                }
                else {
                    history_arr[0] = total + last_operator;
                }

                numbers[0] = total
                last_operation_history.innerText = history_arr.join(" ")

                numbers.pop();
                calc_operator = last_operator;
            }
            else if (calc_operator != null) {
                last_operation_history.innerText = temp_num + " " + last_operator
                calc_operator = btnclickValue
                numbers = []
                numbers.push(amswertext.innerText)
            }
        }
    }
    lastchar = btnclickValue;
}


function calculate(num1, num2, operator) {

    if (operator === "+") {
        total = (parseFloat)(num1) + (parseFloat)(num2)
    }
    else if (operator === "-") {
        total = (parseFloat)(num1) - (parseFloat)(num2)
    }
    else if (operator === "*") {
        total = (parseFloat)(num1) * (parseFloat)(num2)
    }
    else if (operator === "/") {
        total = (parseFloat)(num1) / (parseFloat)(num2)
    }
    else {
        if (total == amswertext.innerText) {
            return total
        }
        else {
            return amswertext.innerText
        }
    }
    if (!Number.isInteger(total)) {
        total = total.toPrecision(12);
    }
    return parseFloat(total);
}

function button_clear() {
    window.location.reload()
}



function backspace_remove() {
    if (!operators.includes(lastchar)) {
        amswertext = document.getElementById("box");
        var last_num = amswertext.innerText;
        last_num = last_num.slice(0, -1)
        amswertext.innerText = last_num

        if (amswertext.innerText.length == 0) {
            amswertext.innerText = 0
            firstNum = true
        }
    }
}


function calculate_percentage() {
    amswertext = document.getElementById("box");
    var perc_value;
    if (numbers.length > 0 && typeof last_operator != "undefined") {
        var perc_value;

        //  console.log("======"+)
        if (last_operator == "+" || last_operator == "-") {
            perc_value = ((amswertext.innerText / 100) * numbers[0])
        }
        else {
            perc_value = ((amswertext.innerText / 100))
        }
        if (!Number.isInteger(perc_value)) {
            perc_value = perc_value.toFixed(2);
        }
        amswertext.innerText = perc_value
        numbers.push(amswertext.innerText)
        console.log("pppppp=====" + perc_value);


        if (!last_operation_history.innerText.includes("=")) {
            last_operation_history.innerText += " " + numbers[1]
            console.log("ppppp3333333333=====" + perc_value);
        }
    }
    else {
        amswertext.innerText = 0;
    }

    numbers.push(amswertext.innerText)
    if (last_operator != null) {
        var res = calculate(numbers[0], numbers[1], last_operator)
        console.log("res=====" + res);
        amswertext.innerText = perc_value;
        //   amswertext.innerText = res;
        operator_value = "="
    }
}


function clear_entry() {
    amswertext = document.getElementById("box");
    if (numbers.length > 0 && typeof last_operator != "undefined") {
        amswertext.innerText = 0
        var temp = numbers[0]
        numbers = []
        numbers.push(temp)
        firstNum = true;
    }
    else if (numbers.length == 0 && typeof last_operator != "undefined") {
        amswertext.innerText = 0
        numbers = []
        numbers.push("0")
    }
}


document.addEventListener('keydown', keyPressed);
function keyPressed(e) {
    e.preventDefault()
    var dot = document.getElementById("dot").value;

    if (e.key == "Delete") {
        button_clear();
        return;
    }

    var isNumber = isFinite(e.key);
    var enterPress;
    var dotPress;
    var commaPress = false;

    if (e.key == "Enter") {
        enterPress = "=";
    }
    if (e.key == ".") {
        dotPress = dot;
    }
    if (e.key == ",") {
        commaPress = true;
    }

    if (isNumber || operators.includes(e.key) || e.key == "Enter" || e.key == dotPress ||
        commaPress || e.key == "Backspace") {
        if (e.key == "Enter") {
            button_number(enterPress)
        }
        else if (e.key == "Backspace") {
            backspace_remove()
        }
        else if (commaPress) {
            button_number(dot)
        }
        else {
            button_number(e.key)
        }
    }
    if (e.key) {
        key_combination[e.code] = e.key;
    }
}